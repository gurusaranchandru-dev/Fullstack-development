package javafullstack;

public class SingleInhereitance {

	public static void main(String[] args) {
		

	}

}
