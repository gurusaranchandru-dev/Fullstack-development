package javafullstack;
class GrandParents{
	void home() {
		System.out.println("Grand Parents");
		
	}
}
class Parents extends GrandParents{
	void properties() {
		System.out.println("Parent's Properties");
		
	}
}
class Child extends Parents{  
	void bikes() {
		System.out.println("Child's Bikes");
		
	}
}

public class MultipleInheritance {

	public static void main(String[] args) {
		Child c = new Child();
		c.home();
		c.properties();
		c.bikes();
	}

}
