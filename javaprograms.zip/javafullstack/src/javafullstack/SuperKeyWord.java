package javafullstack;

public class SuperKeyWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
