package javafullstack;
class Animal{
	void eat() {
		System.out.println("All Animals Can Eat");
	}
}
class Dog extends Animal{
	void barks() {
		System.out.println("Dogs Bark's");
	}
}
class Cat extends Animal{
	void meows() {
		System.out.println("Cats Meows");
	}
}

public class HierarchicalInheritance {

	public static void main(String[] args) {
		Dog d = new dog
		

	}

}
