package chapter3_1;

public class OddNum1to15 {
	 public static void main(String[] args) {
	        for (int i = 1; i <= 15; i++) {
	            if (i % 2 == 0)
	                continue;

	            System.out.println(i);
	        }
	    }

}
