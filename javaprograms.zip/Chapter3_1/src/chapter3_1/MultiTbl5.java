package chapter3_1;

public class MultiTbl5 {
	public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            if (5 * i > 30)
                break;

            System.out.println("5 x " + i + " = " + (5 * i));
        }
    }

}
