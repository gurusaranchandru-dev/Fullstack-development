package chapter2;

public class ConcatenateString {
	public static void main(String[] args) {
        String arr[] = {"Hello", "Java", "World"};
        String result = "";

        for (String s : arr)
            result += s + " ";

        System.out.println(result);
    }

}
