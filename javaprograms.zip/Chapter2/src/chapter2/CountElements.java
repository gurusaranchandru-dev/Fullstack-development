package chapter2;

public class CountElements {
	public static void main(String[] args) {
        int arr[] = {10, 20, 10, 30, 10};
        int key = 10, count = 0;

        for (int x : arr)
            if (x == key)
                count++;

        System.out.println("Count = " + count);
    }

}
