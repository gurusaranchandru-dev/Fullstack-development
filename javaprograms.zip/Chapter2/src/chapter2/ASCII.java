package chapter2;
import java.util.*;

public class ASCII {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		char c='B';
		int ascii= c;
		System.out.println(ascii);
		sc.close();
	}

}

