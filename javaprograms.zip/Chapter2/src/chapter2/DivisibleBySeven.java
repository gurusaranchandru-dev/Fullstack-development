package chapter2;

public class DivisibleBySeven {

}
