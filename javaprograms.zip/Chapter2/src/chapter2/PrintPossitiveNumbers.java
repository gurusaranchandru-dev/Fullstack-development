package chapter2;

public class PrintPossitiveNumbers {public static void main(String[] args) {
    int arr[] = {-5, 10, -2, 20, 30};

    for (int x : arr)
        if (x > 0)
            System.out.println(x);
}
	

}
