package chapter2;

public class ElementsInArray {
	public static void main(String[] args) {
        String arr[] = {"Java", "Python", "C"};

        for (String s : arr)
            System.out.println(s);
    }

}
