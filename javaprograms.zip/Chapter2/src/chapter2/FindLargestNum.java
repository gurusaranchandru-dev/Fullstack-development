package chapter2;

public class FindLargestNum {
	 public static void main(String[] args) {
	        int arr[] = {10, 50, 20, 80, 30};
	        int max = arr[0];

	        for (int x : arr)
	            if (x > max)
	                max = x;

	        System.out.println("Largest = " + max);
	    }

}
