package chapter2;

public class FindAvgDouble {
	 public static void main(String[] args) {
	        double arr[] = {10.5, 20.5, 30.5};
	        double sum = 0;

	        for (double x : arr)
	            sum += x;

	        System.out.println("Average = " + (sum / arr.length));
	    }
}
