package chapter2;

public class CountEvenNum {
	public static void main(String[] args) {
        int arr[] = {10, 15, 20, 25, 30};
        int count = 0;

        for (int x : arr)
            if (x % 2 == 0)
                count++;

        System.out.println("Even Count = " + count);
    }

}
