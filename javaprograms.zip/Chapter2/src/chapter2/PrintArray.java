package chapter2;

public class PrintArray {
	public static void main(String[] args) {
        char arr[] = {'J', 'A', 'V', 'A'};

        for (char c : arr)
            System.out.println(c);
    }

}
