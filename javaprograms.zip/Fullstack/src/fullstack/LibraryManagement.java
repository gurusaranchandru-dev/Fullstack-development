package fullstack;
class Person {
    String name;

    Person(String name) {
        this.name = name;
    }
}
class LibraryStudent extends Person {
    String book;

    LibraryStudent(String name, String book) {
        super(name);
        this.book = book;
    }

    void display() {
        System.out.println("Student Name : " + name);
        System.out.println("Book Issued  : " + book);
    }
}

public class LibraryManagement {

    public static void main(String[] args) {

        LibraryStudent s1 = new LibraryStudent("Guru", "Java Programming");

        s1.display();
    }
}