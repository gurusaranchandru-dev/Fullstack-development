package fullstack;

class Employee {
    int id;
    String name;
    double salary;

    Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    void display() {
        System.out.println("Employee ID: " + id);
        System.out.println("Employee Name: " + name);
        System.out.println("Salary: " + salary);
    }
}

public class Payrollsystem {
    public static void main(String[] args) {

        Employee e1 = new Employee(1, "Chandru", 30000);
        Employee e2 = new Employee(2, "Guru", 35000);
        Employee e3 = new Employee(3, "Prasath", 40000);

        e1.display();
        System.out.println();

        e2.display();
        System.out.println();

        e3.display();
    }
}
