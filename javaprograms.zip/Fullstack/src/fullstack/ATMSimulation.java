package fullstack;

class ATM {
    int balance = 10000;

    void showBalance() {
        System.out.println("Current Balance: Rs." + balance);
    }
}

class Customer extends ATM {

    void deposit(int amount) {
        balance = balance + amount;
        System.out.println("Prasath deposited Rs." + amount);
    }

    void withdraw(int amount) {
        if (amount <= balance) {
            balance = balance - amount;
            System.out.println("Prasath withdrew Rs." + amount);
        } else {
            System.out.println("Insufficient Balance");
        }
    }
}

public class ATMSimulation {
    public static void main(String[] args) {

        Customer c = new Customer();

        c.showBalance();
        c.deposit(2000);
        c.showBalance();
        c.withdraw(1500);
        c.showBalance();
    }
}
