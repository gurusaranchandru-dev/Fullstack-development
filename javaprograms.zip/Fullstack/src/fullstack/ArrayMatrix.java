package fullstack;

public class ArrayMatrix {

	public static void main(String[] args) {
		int[][] matrix = {
				{3, 0, 0, 0},
				{0, 3, 0, 0},
				{0, 0, 3, 0},
				{0, 0, 0, 3},
		};
		for (int i=0; i<4; i++) {
			for (int j=0; j < 4; j++) {
				System.out.print(matrix[i][j]+ "");
				
				}
		System.out.println();
			}
		}

	}


