package fullstack;

class College {

    String collegeName = "Selvamm Arts and Science College";

    void collegeDetails() {
        System.out.println("College Name : " + collegeName);
    }
}

class CollegeStudent extends College {

    String studentName = "Chandru";
    int rollNo = 57;

    void studentDetails() {
        System.out.println("Student Name : " + studentName);
        System.out.println("Roll Number : " + rollNo);
    }
}

public class CollegeManagement {

    public static void main(String[] args) {

        CollegeStudent s = new CollegeStudent();

        s.collegeDetails();
        s.studentDetails();
    }
}