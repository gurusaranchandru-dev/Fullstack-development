package fullstack;

	class Student {
	    int id;
	    String name;
	    int marks;

	    Student(int id, String name, int marks) {
	        this.id = id;
	        this.name = name;
	        this.marks = marks;
	    }

	    void display() {
	        System.out.println("Student ID: " + id);
	        System.out.println("Student Name: " + name);
	        System.out.println("Marks: " + marks);
	    }
	}

	public class StudentManagementSystem {
	    public static void main(String[] args) {

	        Student s1 = new Student(101, "Chandru", 90);
	        Student s2 = new Student(102, "Guru", 85);
	        Student s3 = new Student(103, "Prasath", 95);

	        s1.display();
	        System.out.println();

	        s2.display();
	        System.out.println();

	        s3.display();
	    }
	}


