package fullstack;

class BankAccount {
    String name;
    double balance;

    BankAccount(String name, double balance) {
        this.name = name;
        this.balance = balance;
    }

    void deposit(double amount) {
        balance = balance + amount;
    }

    void display() {
        System.out.println("Account Holder: " + name);
        System.out.println("Balance: " + balance);
    }
}

public class BankingApplication {
    public static void main(String[] args) {

        BankAccount b1 = new BankAccount("Chandru", 5000);
        BankAccount b2 = new BankAccount("Guru", 7000);
        BankAccount b3 = new BankAccount("Prasath", 9000);

        b1.deposit(1000);
        b2.deposit(500);
        b3.deposit(2000);

        b1.display();
        System.out.println();

        b2.display();
        System.out.println();

        b3.display();
    }
}
