package fullstack;

import java.util.Scanner;

public class StudentMarks {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int[] marks = new int[5];

        System.out.println("Enter 5 student marks:");

        for (int i = 0; i < 5; i++) {
            System.out.print("Mark " + (i + 1) + ": ");
            marks[i] = scanner.nextInt();
        }

        System.out.println("\nStudent Marks:");

        for (int i = 0; i < 5; i++) {
            System.out.println("Mark " + (i + 1) + " = " + marks[i]);
        }

        scanner.close();
    }
}